'''
Created on Feb 8, 2022

@author: mithul

'''


print(" hello ... ")
favColor = input(" enter your favourite color : " )
petName = input(" enter your pet's name : ")
userNum = int(input(" enter a integer number : "))

print(" You entered : ", favColor , petName , userNum)

'''
lets create two passwords 
pwd1   firststring_secondstring 
pwd2     numfirststringnum 
 
'''

passwd1 = favColor + "_" + petName
passwd2 = str(userNum) + favColor + str(userNum)

print(" \npassword one is :", passwd1)
print(" \npassword two is :",passwd2 )

print(" number of characters in %s: %d " %(passwd1,len(passwd1)))
print(" number of characters in %s: %d " %(passwd2,len(passwd2)))


print("\nEND")

